<?php

namespace App\Enums;
class Gender extends Enum
{
    private const MALE    = 'male';
    private const FEMALE  = 'female';
    private const OTHER   = 'other';
}
