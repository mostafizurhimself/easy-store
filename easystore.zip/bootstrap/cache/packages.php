<?php return array (
  '64robots/nova-fields' => 
  array (
    'providers' => 
    array (
      0 => 'R64\\NovaFields\\FieldServiceProvider',
    ),
  ),
  'armincms/json' => 
  array (
    'providers' => 
    array (
    ),
  ),
  'benjacho/belongs-to-many-field' => 
  array (
    'providers' => 
    array (
      0 => 'Benjacho\\BelongsToManyField\\FieldServiceProvider',
    ),
  ),
  'benjaminhirsch/nova-slug-field' => 
  array (
    'providers' => 
    array (
      0 => 'Benjaminhirsch\\NovaSlugField\\FieldServiceProvider',
    ),
  ),
  'bissolli/nova-phone-field' => 
  array (
    'providers' => 
    array (
      0 => 'Bissolli\\NovaPhoneField\\FieldServiceProvider',
    ),
  ),
  'bolechen/nova-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Bolechen\\NovaActivitylog\\ToolServiceProvider',
    ),
  ),
  'cloudcake/nova-fixed-bars' => 
  array (
    'providers' => 
    array (
      0 => 'NovaFixedBars\\NovaFixedBarsServiceProvider',
    ),
  ),
  'david-griffiths/nova-dark-theme' => 
  array (
    'providers' => 
    array (
      0 => 'DavidGriffiths\\NovaDarkTheme\\ThemeServiceProvider',
    ),
  ),
  'dillingham/nova-ajax-select' => 
  array (
    'providers' => 
    array (
      0 => 'NovaAjaxSelect\\FieldServiceProvider',
    ),
  ),
  'dillingham/nova-attach-many' => 
  array (
    'providers' => 
    array (
      0 => 'NovaAttachMany\\Providers\\FieldServiceProvider',
    ),
  ),
  'easystore/nova-theme' => 
  array (
    'providers' => 
    array (
      0 => 'Easystore\\NovaTheme\\ThemeServiceProvider',
    ),
  ),
  'easystore/permission-checkbox' => 
  array (
    'providers' => 
    array (
      0 => 'Easystore\\PermissionCheckbox\\FieldServiceProvider',
    ),
  ),
  'easystore/router-link' => 
  array (
    'providers' => 
    array (
      0 => 'Easystore\\RouterLink\\FieldServiceProvider',
    ),
  ),
  'ebess/advanced-nova-media-library' => 
  array (
    'providers' => 
    array (
      0 => 'Ebess\\AdvancedNovaMediaLibrary\\AdvancedNovaMediaLibraryServiceProvider',
    ),
  ),
  'eminiarts/nova-permissions' => 
  array (
    'providers' => 
    array (
      0 => 'Eminiarts\\NovaPermissions\\ToolServiceProvider',
    ),
  ),
  'eminiarts/nova-tabs' => 
  array (
    'providers' => 
    array (
      0 => 'Eminiarts\\Tabs\\TabsServiceProvider',
    ),
  ),
  'epartment/nova-dependency-container' => 
  array (
    'providers' => 
    array (
      0 => 'Epartment\\NovaDependencyContainer\\FieldServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'gregoriohc/laravel-nova-theme-responsive' => 
  array (
    'providers' => 
    array (
      0 => 'Gregoriohc\\LaravelNovaThemeResponsive\\ThemeServiceProvider',
    ),
  ),
  'hubertnnn/laravel-nova-field-dynamic-select' => 
  array (
    'providers' => 
    array (
      0 => 'Hubertnnn\\LaravelNova\\Fields\\DynamicSelect\\FieldServiceProvider',
    ),
  ),
  'inspheric/nova-defaultable' => 
  array (
    'providers' => 
    array (
      0 => 'Inspheric\\NovaDefaultable\\DefaultableServiceProvider',
    ),
  ),
  'inspheric/nova-email-field' => 
  array (
    'providers' => 
    array (
      0 => 'Inspheric\\Fields\\EmailFieldServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'kirschbaum-development/nova-inline-relationship' => 
  array (
    'providers' => 
    array (
      0 => 'KirschbaumDevelopment\\NovaInlineRelationship\\NovaInlineRelationshipServiceProvider',
    ),
  ),
  'laravel/nova' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Nova\\NovaCoreServiceProvider',
    ),
    'aliases' => 
    array (
      'Nova' => 'Laravel\\Nova\\Nova',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'orlyapps/nova-belongsto-depend' => 
  array (
    'providers' => 
    array (
      0 => 'Orlyapps\\NovaBelongsToDepend\\FieldServiceProvider',
    ),
  ),
  'pdmfc/nova-action-button' => 
  array (
    'providers' => 
    array (
      0 => 'Pdmfc\\NovaFields\\ActionButtonFieldServiceProvider',
    ),
  ),
  'spatie/laravel-activitylog' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Activitylog\\ActivitylogServiceProvider',
    ),
  ),
  'spatie/laravel-medialibrary' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\MediaLibrary\\MediaLibraryServiceProvider',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'yassi/nova-nested-form' => 
  array (
    'providers' => 
    array (
      0 => 'Yassi\\NestedForm\\FieldServiceProvider',
    ),
  ),
);