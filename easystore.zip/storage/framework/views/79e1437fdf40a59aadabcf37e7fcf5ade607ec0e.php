<dropdown-trigger class="h-9 flex items-center">
    <?php if(isset($user->email)): ?>
        <img
            <?php if(Auth::user()->hasMedia('avatar')): ?>
            src="<?php echo e(Auth::user()->getFirstMediaUrl('avatar')); ?>"
            <?php else: ?>
            src="https://secure.gravatar.com/avatar/<?php echo e(md5($user->email)); ?>?size=512"
            <?php endif; ?>
            class="rounded-full w-8 h-8 mr-3"
        />
    <?php endif; ?>

    <span class="text-90">
        <?php echo e($user->name ?? $user->email ?? __('Nova User')); ?>

    </span>
</dropdown-trigger>

<dropdown-menu slot="menu" width="200" direction="rtl">
    <ul class="list-reset">
        <li>
            <router-link to="/resources/users/<?php echo e(Auth::user()->id); ?>/edit" class=" block no-underline text-90 hover:bg-30 p-3">
                <i class="fas fa-lock ml-2" style="min-width:2rem"></i>Profile
            </router-link>
        </li>
        <li>
            <a href="<?php echo e(route('nova.logout')); ?>" class=" block no-underline text-90 hover:bg-30 p-3">
               <i class="fas fa-sign-out-alt ml-2" style="min-width:2rem;"></i>Logout
            </a>
        </li>
        <li>
            <nova-dark-theme-toggle
                label="<?php echo e(__('Dark Theme')); ?>"
            ></nova-dark-theme-toggle>
        </li>
    </ul>
</dropdown-menu>
<?php /**PATH C:\laragon\www\easystore\resources\views/vendor/nova/partials/user.blade.php ENDPATH**/ ?>