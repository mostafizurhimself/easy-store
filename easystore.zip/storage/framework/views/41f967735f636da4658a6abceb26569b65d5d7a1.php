<p class="mt-8 text-center text-xs text-80">
    <span class="px-1">&middot;</span>
    Copyright &copy; <?php echo e(date('Y')); ?> <?php echo e(Settings::company()->name ?? \Laravel\Nova\Nova::name()); ?> All rights reserved - Developed By <a href="http://ahmedshakil.com" class="text-primary dim no-underline">Ahmed Shakil</a>
    <span class="px-1">&middot;</span>
    v<?php echo e(\Laravel\Nova\Nova::version()); ?>

</p>
<?php /**PATH C:\laragon\www\easystore\resources\views/vendor/nova/partials/footer.blade.php ENDPATH**/ ?>