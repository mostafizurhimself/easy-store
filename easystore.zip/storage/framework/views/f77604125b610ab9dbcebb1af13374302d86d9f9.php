<router-link exact tag="h3"
    :to="{
        name: 'dashboard.custom',
        params: {
            name: 'main'
        }
    }"
    class="cursor-pointer flex items-center font-normal dim text-white mb-8 text-base no-underline">
    
    <i class="fas fa-home mr-3"></i>
    <span class="text-white sidebar-label"><?php echo e(__('Dashboard')); ?></span>
</router-link>
<?php if(\Laravel\Nova\Nova::availableDashboards(request())): ?>
    <ul class="list-reset mb-8">
        <?php $__currentLoopData = \Laravel\Nova\Nova::availableDashboards(request()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dashboard): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="leading-wide mb-4 text-sm">
                <router-link :to='{
                    name: "dashboard.custom",
                    params: {
                        name: "<?php echo e($dashboard::uriKey()); ?>",
                    },
                    query: <?php echo json_encode($dashboard->meta(), 15, 512) ?>,
                }'
                exact
                class="text-white ml-8 no-underline dim">
                    <?php echo e($dashboard::label()); ?>

                </router-link>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php /**PATH C:\laragon\www\easystore\resources\views/vendor/nova/dashboard/navigation.blade.php ENDPATH**/ ?>