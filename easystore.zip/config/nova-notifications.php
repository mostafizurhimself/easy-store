<?php

return [
    // The Echo namespaced path to the User model
    'user_model' => 'App.Models.User',
];
