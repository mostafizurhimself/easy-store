<template>
  <div class="help-text" v-html="$slots.default[0].text" />
</template>

<script>
export default {}
</script>
